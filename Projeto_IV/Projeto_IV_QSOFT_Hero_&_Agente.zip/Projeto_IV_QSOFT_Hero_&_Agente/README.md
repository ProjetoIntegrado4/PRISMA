# Projeto IV - Prisma - Versão Corrigida

Exemplo didático com:

- **Spring Boot / Java 17**: domínio de Empresa e Consumo de IA;
- **PostgreSQL**: persistência;
- **Node.js Alert Service**: microserviço independente para avaliação de consumo;
- **Node.js Front/BFF**: serve a interface e atua como proxy (BFF) para o backend Java;
- **Docker Compose**: sobe todo o ambiente.

## Arquitetura

```text
Browser :3000
   |
   v
Node.js Front/BFF :3000
   |
   v
Spring Boot :8080 ------> Node Alert Service :3001
   |
   v
PostgreSQL :5432
```

## Requisito Empresa

A Empresa é requisito explícito do domínio. Cada empresa possui um UUID e um consumo de IA só pode ser registrado para uma empresa existente.

Fluxo:

1. `POST /api/empresa` cria a empresa;
2. o Java gera um `UUID` para a empresa;
3. `POST /api/usages` recebe `empresaId`;
4. o Spring valida se a empresa existe;
5. persiste o consumo;
6. chama o Node Alert Service;
7. devolve consumo + alerta ao BFF/front.

## Base de dados dos cadastros (CSV)

Empresas, funcionários e admins ficam na **base de dados em CSV**, não no PostgreSQL. A sincronização
vale nos dois sentidos:

- o que for cadastrado no site é gravado no fim do CSV correspondente;
- o que for acrescentado nos CSVs (por script, Excel ou à mão) aparece no site na próxima vez que a
  lista for carregada. O backend relê o arquivo sempre que ele muda no disco.

| Cadastro     | Arquivo           | Código gerado                  |
|--------------|-------------------|--------------------------------|
| Empresa      | `companies.csv`   | `C19`, `C20`...                |
| Funcionário  | `employees.csv`   | `C01-E0364`... (por empresa)   |
| Setor        | `departments.csv` | `C01-D12`... (criado se o setor digitado não existir) |
| Admin        | `admins.csv`      | `C01-A001`... (arquivo criado no primeiro cadastro) |

As colunas originais da base continuam as mesmas. Os campos que só o site tem (razão social, CNPJ,
nome, CPF, e-mail, telefone, matrícula, hash da senha, gestor) entram como colunas extras no fim do
arquivo, vazias nas linhas antigas. Senhas são gravadas apenas como hash BCrypt. O id usado pela API é
derivado do código (`C01` sempre tem o mesmo id), e a coluna "Código" das telas mostra esse código.

**Onde fica a pasta.** O caminho está num único lugar: a variável `PRISMA_DADOS_DIR` do arquivo `.env`
na raiz do projeto. Ela é usada pelo `docker compose` (volume do backend, montado em `/app/dados`) e
pelo Spring quando roda fora do Docker. Para apontar para outra pasta (por exemplo, a pasta Git):

```text
PRISMA_DADOS_DIR=C:/caminho/da/nova/pasta
```

Depois, reinicie o backend: `docker compose up -d --force-recreate backend`. Sem `.env`, o padrão é
`dados/csv`. O painel de produtividade importa os CSVs da mesma pasta.

## Subir pelo Docker

Na pasta raiz:

```bash
docker compose down -v
docker compose build --no-cache
docker compose up
```

Acessos:

- Front/BFF: http://localhost:3000
- Login: http://localhost:3000/login.html
- Spring Boot: http://localhost:8080
- Swagger: http://localhost:8080/swagger-ui/index.html
- Alert Service health: http://localhost:3001/health
- pgAdmin: http://localhost:5050

pgAdmin:

- e-mail: `admin@admin.com`
- senha: `admin`
- host do PostgreSQL dentro do Docker: `postgres`
- porta: `5432`
- database: `iadb`
- usuário: `ia`
- senha: `ia`

## Login e perfis de acesso

Há três perfis:

- **Administrador** (`ADMIN`): visão completa (Cadastros, Monitoramento e Governança, inclusive publicar política).
- **Gerente** (`GERENTE`): igual ao administrador, mas não cadastra empresas. É cadastrado na tela de
  Administradores, escolhendo o nível de acesso "Gerente" (`nivel_acesso = GERENTE` em `admins.csv`).
- **Funcionário** (`FUNCIONARIO`): Início (com botão para a Produtividade de IA), todas as páginas de Monitoramento e
  Governança sem publicar política. Ao abrir a Governança, já vê a própria empresa e os próprios aceites.

O backend barra o funcionário nos cadastros (`/api/admin`, `/api/certificacao`, gravação em `/api/empresa` e
`/api/funcionario`) e na publicação de políticas; o BFF devolve o funcionário ao Início se ele abrir uma página de cadastro.

Contas que funcionam:

| Perfil | Usuário | Senha |
|---|---|---|
| Administrador (temporário) | `admin@prisma.com` | `Prisma123!` |
| Gerente (temporário) | `gerente@prisma.com` | `Prisma123!` |
| Funcionário (temporário) | `funcionario@prisma.com` | `Prisma123!` |
| Administrador da base (`admins.csv`) | e-mail do admin, ex.: `leticia.rocha@nexocodesolucoes.com.br` | `Qsoft@2026` |
| Funcionário da base (`employees.csv`, ativo) | e-mail corporativo, ex.: `luana.araujo@nexocodesolucoes.com.br` | `Qsoft@2026` |

Todo admin, gerente ou funcionário cadastrado pelo site já entra com o e-mail e a senha do cadastro; o e-mail não
pode repetir entre os cadastros. Admins antigos da base com outro nível (TOTAL, GESTOR) continuam como administrador.
Na base, só entram contas ativas (`status_conta = ATIVO` nos admins, `active = True` nos funcionários), e a senha é
conferida com o hash BCrypt da coluna `senha_hash`. As contas temporárias ficam em `application.yml` e podem ser trocadas
por `TEMP_LOGIN_*` e `TEMP_GERENTE_*`, `TEMP_FUNCIONARIO_USERNAME`, `TEMP_FUNCIONARIO_PASSWORD` e `TEMP_FUNCIONARIO_NAME`.

## Teste manual da API

Criar empresa:

```bash
curl -X POST http://localhost:8080/api/empresa \
  -H "Content-Type: application/json" \
  -d '{"name":"ACCamargo","area":"Saude"}'
```

Copie o `id` retornado e use como `empresaId`:

```bash
curl -X POST http://localhost:8080/api/usages \
  -H "Content-Type: application/json" \
  -d '{"empresaId":"COLE-O-UUID-AQUI","tokens":6000,"model":"gpt-demo"}'
```

Com 6000 tokens, o serviço Node deverá responder com alerta `WARNING`.

## BFF

O BFF faz o **proxy** em `/api/*`, evitando que o browser conheça diretamente o endereço do Spring, e só entrega as páginas a quem tem sessão válida. A visão consolidada dos dados fica no Painel de Produtividade de IA (`produtividade.html`), que lê tudo do banco pelo backend.

## Capacitações e certificações em IA (US PP-19)

Página `frontend/public/capacitacao.html` (menu "Capacitações"). O colaborador é escolhido pela empresa e pelo
nome, porque ainda não existe login de funcionário (o acesso atual é o admin temporário).

- `POST /api/certificacao`: registra um curso ou certificação (`funcionarioId`, `empresaId`, `nome`, `instituicao`,
  `dataConclusao` no formato `AAAA-MM-DD`, `tipo` = `CURSO` ou `CERTIFICACAO`);
- `GET /api/certificacao?funcionarioId=...`: histórico do colaborador, do mais recente para o mais antigo;
- `GET /api/certificacao/resumo?funcionarioId=...`: total de registros e pontos de AI Literacy.

Regras: nome, instituição e data de conclusão são obrigatórios (nome e instituição com até 150 caracteres), a data
não pode ser futura e o colaborador precisa existir e ser da empresa informada. Os registros ficam na base de dados em CSV, no mesmo arquivo dos treinamentos (`training_records.csv`, repositório `repository/csv/CertificacaoCsvRepository`): o histórico mostra os treinamentos concluídos que já estão na base e cada novo registro vira uma linha nova (`completion_status` = `Concluido`), com instituição, tipo e data do registro em colunas extras no fim do arquivo.

Os pontos de AI Literacy por registro ficam em `app.ai-literacy` no `application.yml` e são aplicados só em
`service/PontuacaoAiLiteracy`. Os valores atuais (curso = 10, certificação = 20) são **preliminares** e precisam ser
validados com o PO.

## Custos de IA (US PP-18)

Página `frontend/public/custos.html` (menu "Custos de IA"). O gestor escolhe a empresa, o período (já vem preenchido
com o último mês que tem uso registrado) e, se quiser, um departamento **ou** um colaborador, e clica em "Calcular".
A tela mostra o custo total, os usos cobrados, agentes × uso direto, os usos sem preço, tabelas por departamento,
colaborador (os de maior custo) e ferramenta, e a memória de cálculo (versão da regra, vigência e fórmula).
Se o período não tiver uso, o total é 0 e aparece "Nenhum uso de IA registrado no período selecionado".

Os dados vêm das tabelas analíticas importadas de `dados/csv` (`ai_usage_logs`, `ai_models`, `companies`,
`departments`, `employees`, `ai_tools`), com ids como `C01`, `C01-D02` e `C01-E0001`. Elas **não** são as entidades
Empresa/Funcionario (UUID) do CRUD. As tabelas `uso_custo` (ai_usage_logs com `model_id` e `application`) e `modelos`
(ai_models) foram acrescentadas ao `produtividade.yml`; as demais reaproveitam o mapeamento do painel.

**Endpoints** (exigem login, como os demais; erros de validação respondem 400 com `message`):

- `GET /api/custos/opcoes[?empresaId=C01]`: empresas e, para a empresa informada, seus departamentos e colaboradores;
  traz também `dataMinima` e `dataMaxima` do uso registrado;
- `GET /api/custos?empresaId=C01&inicio=2026-07-01&fim=2026-07-31[&departamentoId=C01-D02 | &colaboradorId=C01-E0001]`:
  `total`, `moeda`, `usosCobrados`, `usosSemPreco`, `tokensEntrada`, `tokensSaida`, `totalAgentes`, `totalUsoDireto`,
  `porDepartamento[]`, `porColaborador[]`, `porFerramenta[]`, `versaoRegra`, `vigencia`, `formula`, `statusCobrados`,
  `aplicacoesAgente`, `mensagem` e `indisponiveis`.

Validações: empresa, início e fim obrigatórios (datas em `AAAA-MM-DD`, fim inclusive); início ≤ fim; departamento e
colaborador precisam ser da empresa; não aceita os dois filtros ao mesmo tempo. Se as tabelas não existirem no banco,
a resposta vem com `total: null`, a mensagem e o motivo em `indisponiveis` (mesmo padrão do painel de produtividade).

**Regra de cálculo** (aplicada só em `service/custos/RegraCusto`, configurada na seção `custos` do `application.yml`):

```
custo por uso = input_tokens / 1000 × input_price_usd_per_1k_tokens + output_tokens / 1000 × output_price_usd_per_1k_tokens
```

- moeda `USD`, sem conversão de câmbio;
- só entram usos com status em `status-cobrados` (`[success]`);
- usos cuja `application` está em `aplicacoes-agente` (`Pipeline Interno`, `Integracao via Backend Interno`,
  `API Direta`) somam em `totalAgentes`; os demais, em `totalUsoDireto`;
- uso de modelo sem preço não vira custo zero: fica fora do total e é contado em `usosSemPreco` (RN19);
- a versão (`custos-v1-preliminar`) e a vigência voltam em toda resposta, com a fórmula (RN17);
- `limite-colaboradores` (10) define quantos colaboradores aparecem no detalhamento.

O banco faz a soma (`SUM`/`GROUP BY` por dimensão × modelo × agente, filtrando empresa, período e status) e o Java
aplica o preço de cada modelo. Como a fórmula é linear nos tokens, o resultado é o mesmo de somar uso a uso, sem
carregar os ~269 mil registros na memória.

**Pendências para validar com o PO** (a regra está marcada como PRELIMINAR):

1. moeda e câmbio: os preços de `ai_models` estão em USD, mas `ai_billing` está em BRL; falta definir se a tela
   converte e com qual cotação;
2. status cobrados: hoje só `success`; `error`, `timeout` e `rate_limited` também consomem tokens nos registros;
3. lista de "agentes": as três aplicações acima foram escolhidas por serem integrações automáticas, sem usuário;
4. não existe "equipe" nos dados (só empresa, departamento, colaborador, projeto e centro de custo), então o filtro
   por equipe da US não foi implementado.

## Políticas de uso de IA e aceite (US PP-21)

Página `frontend/public/governanca.html` (menu "Governança"), com duas partes:

- **Administrador:** escolhe a empresa, informa título e texto, marca se o aceite é obrigatório e clica em
  "Publicar". A lista mostra as políticas vigentes com a versão; "Nova versão" carrega o texto atual para editar e
  publica a versão seguinte; "Histórico" mostra todas as versões (vigente e substituídas) e o texto de cada uma.
- **Colaborador (provisório):** como ainda não existe login de funcionário, o colaborador é escolhido pela empresa e
  pelo nome. A tela mostra as políticas obrigatórias pendentes com o texto completo e o botão "Li e aceito", e o
  histórico de aceites (versão e data).

Em `consumo.html` há um seletor **opcional** de colaborador. Se o uso for bloqueado, aparece a mensagem com as
políticas pendentes e um link que abre a Governança já no colaborador.

**Endpoints** (exigem login como os demais; erros respondem com `message`: 400 validação, 401 sem login, 403 sem
perfil Administrador, 404 empresa/funcionário/política inexistente, 409 uso bloqueado):

- `POST /api/politicas` – publica a versão 1: `{"empresaId","titulo","conteudo","obrigatoria"}` (**só Administrador**);
- `PUT /api/politicas/{codigo}` – publica a próxima versão (`empresaId` pode ser omitido; não pode trocar de empresa)
  (**só Administrador**);
- `GET /api/politicas?empresaId=...` – versões vigentes da empresa;
- `GET /api/politicas/{codigo}/versoes` – histórico de versões, da mais recente para a mais antiga;
- `GET /api/politicas/pendentes?empresaId=...&funcionarioId=...` – vigentes e obrigatórias que o colaborador não aceitou;
- `POST /api/politicas/aceites` – `{"funcionarioId","politicaId"}`, em que `politicaId` é o `id` da **versão**;
- `GET /api/politicas/aceites?funcionarioId=...` – histórico de aceites, incluindo versões antigas.

`POST /api/usages` aceita o campo opcional `funcionarioId`. Sem ele, nada muda. Com ele, o funcionário precisa existir
(404) e ser da empresa (400); se houver política vigente e obrigatória sem aceite, o uso **não é salvo** e a resposta é
`409` com `"message": "Aceite da política de uso de IA obrigatório"` e a lista `pendentes`.

**Regras**

- cada linha de `politica_uso` é uma versão; as versões da mesma política têm o mesmo `codigo` e só a última fica
  `vigente`. Nenhuma versão é apagada (RN14, CA-14.3);
- título obrigatório (até 150 caracteres) e conteúdo obrigatório (até 20.000);
- o aceite (`aceite_politica`) guarda funcionário, versão e data (RN15) e só pode ser feito na versão vigente, por
  funcionário da mesma empresa da política;
- nova versão exige novo aceite; o histórico de aceites continua disponível (CA-15.4);
- aceitar de novo a mesma versão devolve o aceite existente (200), sem duplicar nem mudar a data;
- política **não** obrigatória não bloqueia o uso;
- RN04/CA-14.1: `POST`/`PUT` de política exigem `ROLE_ADMIN` (`SecurityConfig`). O admin temporário tem esse perfil.
  Quando existir login de colaborador, ele não terá `ROLE_ADMIN` e receberá 403 ao tentar publicar.

As tabelas `politica_uso` e `aceite_politica` são criadas pelo Hibernate (`ddl-auto: update`).

Teste manual pela API (com o cookie de sessão e o token CSRF, como no navegador; pelo BFF basta usar a tela):

```bash
curl -c c.txt -b c.txt http://localhost:8080/api/auth/csrf
TOKEN=$(grep XSRF-TOKEN c.txt | awk '{print $7}')
curl -c c.txt -b c.txt -H "X-XSRF-TOKEN: $TOKEN" -H "Content-Type: application/json" \
  -d '{"usuario":"admin@prisma.com","senha":"Prisma123!"}' http://localhost:8080/api/auth/login
curl -b c.txt -H "X-XSRF-TOKEN: $TOKEN" -H "Content-Type: application/json" \
  -d '{"empresaId":"UUID-DA-EMPRESA","titulo":"Uso responsável de IA","conteudo":"Não insira dados pessoais.","obrigatoria":true}' \
  http://localhost:8080/api/politicas
```

Conformidade LGPD (dados guardados, finalidade, acesso, retenção e pontos em aberto):
[`docs/lgpd/conformidade-politicas.md`](docs/lgpd/conformidade-politicas.md).

**Limitações e pendências**

1. não existe login de colaborador: o colaborador é escolhido na tela, e qualquer usuário autenticado consegue
   registrar aceite ou consultar o histórico de qualquer colaborador. Com o login, o `funcionarioId` deve vir da sessão;
2. o bloqueio só vale quando o registro de uso informa `funcionarioId` (usos sem colaborador continuam como antes);
3. base legal, prazo de retenção e procedimento de exclusão/anonimização dos aceites estão **A VALIDAR** (ver o
   documento LGPD);
4. o comportamento do aceite repetido (devolver o existente em vez de 409) precisa ser confirmado com o PO.

## Painel de Produtividade de IA

Página `frontend/public/produtividade.html` (menu "Produtividade IA"). Os dados vêm do backend em
`GET /api/produtividade/resumo` e `GET /api/produtividade/empresas/{id}` (`ALL` para todas as empresas).

**Mapeamento do banco (`src/main/resources/produtividade.yml`).** As consultas usam nomes lógicos
(`${uso}`, `${uso.funcionario}`); o arquivo diz qual tabela e coluna física corresponde a cada um, quais
valores de status contam (ex.: `uso-sucesso: [success]`), o schema, a janela "recente" em dias e o tamanho
do ranking. Se o banco mudar de nomes ou de valores, ajuste só esse arquivo.

**Seções independentes.** Cada bloco do painel é uma classe em `service/produtividade/secao` que implementa
`SecaoPainel` e declara as tabelas/colunas de que precisa. Antes de calcular, o backend confere no
`information_schema` se elas existem: o que faltar vem nulo no JSON, com o motivo em `indisponiveis`, e a
página esconde o bloco e cita o motivo no rodapé. As seções rodam em paralelo.

Para acrescentar uma análise:
1. mapeie as tabelas novas em `produtividade.yml`;
2. crie as consultas em `repository/produtividade/<Nome>Consultas.java` usando `ConsultaPainel`;
3. crie `service/produtividade/secao/<Nome>Secao.java` (`@Component`, `@Order`) implementando `SecaoPainel`;
4. no frontend, crie `frontend/public/js/produtividade/secoes/<nome>.js`, registre em `SECOES` (`main.js`)
   e marque o HTML com `data-secao="<chave>"`.

**Importação de CSV.** Na subida, cada `*.csv` da pasta da base de dados (`PRISMA_DADOS_DIR`, no `.env`) vira a
tabela de mesmo nome, se ela não existir ou estiver vazia. Os tipos das colunas são deduzidos dos valores, a
primeira coluna `_id` com valores únicos vira chave primária e as demais `_id` ganham índice. Tabelas que já
têm dados não são alteradas. Cada carga da página consulta o banco: registros novos aparecem ao clicar em
"Atualizar dados".

**Frontend.** O HTML só tem a estrutura; o JavaScript fica em `frontend/public/js/produtividade`
(`main.js`, `api.js`, `formato.js`, `componentes/` com gráficos e tabelas, `secoes/` com um módulo por bloco)
e o estilo em `frontend/public/Estilo.css`.

## Testes automatizados e cobertura

Os testes ficam em `src/test/java`, na mesma estrutura de pacotes do código:
`controller`, `service`, `repository`, `integration/alert` e `domainTeste` (entidades e VOs).
Eles não precisam de banco nem do alert-service: os repositórios são simulados com Mockito
e o alert-service é substituído por um servidor HTTP local durante o teste.

```bash
mvn clean verify
```

O `verify` roda os testes e o JaCoCo. O relatório fica em `target/site/jacoco/index.html`
e o build falha se a cobertura de linhas ficar abaixo de 70%. No Jenkins, o mesmo comando
roda na etapa de testes; o relatório é arquivado e publicado pelo plugin Coverage ou JaCoCo
quando um deles estiver instalado.

## Dados de demonstração

- **Base CSV:** `admins.csv` tem dois admins por empresa (Diretor(a) de Inovação e Gestor(a) de TI) e `employees.csv` tem nome, CPF, e-mail, telefone, matrícula e gestor de cada colaborador. A senha de demonstração de todos é `Qsoft@2026`, guardada só como hash BCrypt. O script que gerou esses dados só preenche células vazias e guardou os originais em `_backup_antes_preenchimento`.
- **PostgreSQL:** na subida, `service/demonstracao/DemonstracaoSeeder` popula políticas de uso de IA (três por empresa, uma já na versão 2), aceites e consumo de IA, tudo derivado da base. Aceitam as políticas os colaboradores ativos treinados em Governança ou Segurança e cerca de dois terços dos demais; o restante fica pendente. O consumo traz os 15 usos mais recentes de cada empresa (`ai_usage_logs`). Só preenche tabela vazia. Para desligar, use `PRISMA_DEMONSTRACAO=false`.

